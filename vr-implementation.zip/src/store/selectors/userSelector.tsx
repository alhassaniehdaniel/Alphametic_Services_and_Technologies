export const getAllUsersSelector = (state:any) => state.userReducer;
